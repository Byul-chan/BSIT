import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class NotepadPage extends StatefulWidget {
  @override
  _NotepadPageState createState() => _NotepadPageState();
}

class _NotepadPageState extends State<NotepadPage> {
  final _supabase = Supabase.instance.client;
  List<Map<String, dynamic>> _notes = [];

  @override
  void initState() {
    super.initState();
    _fetchNotes();
  }

  // Fetch notes from Supabase
  Future<void> _fetchNotes() async {
    final response = await _supabase.from('notes').select().execute();
    if (response.error == null) {
      setState(() {
        _notes = List<Map<String, dynamic>>.from(response.data);
      });
    } else {
      print('Error fetching notes: ${response.error?.message}');
    }
  }

  // Add a new note
  Future<void> _addNote() async {
    final titleController = TextEditingController();
    final contentController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text('Add Note',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24)),
        content: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: titleController,
                  decoration: InputDecoration(
                    labelText: 'Title',
                    labelStyle: TextStyle(fontSize: 18),
                    border: OutlineInputBorder(),
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                  ),
                  style: TextStyle(fontSize: 18),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: contentController,
                  decoration: InputDecoration(
                    labelText: 'Content',
                    labelStyle: TextStyle(fontSize: 18),
                    border: OutlineInputBorder(),
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                  ),
                  maxLines: 6,
                  style: TextStyle(fontSize: 18),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              if (titleController.text.isNotEmpty &&
                  contentController.text.isNotEmpty) {
                final response = await _supabase.from('notes').insert({
                  'title': titleController.text,
                  'content': contentController.text,
                }).execute();

                if (response.error == null) {
                  Navigator.pop(context);
                  _fetchNotes();
                } else {
                  print('Error adding note: ${response.error?.message}');
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to add note')));
                }
              } else {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Title and content cannot be empty')));
              }
            },
            child: Text(
              'Save',
              style: TextStyle(fontSize: 18),
            ),
          ),
        ],
      ),
    );
  }

  // Update an existing note
  Future<void> _updateNote(Map<String, dynamic> note) async {
    final titleController = TextEditingController(text: note['title']);
    final contentController = TextEditingController(text: note['content']);

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: Text('Update Note',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 24)),
        content: Padding(
          padding: const EdgeInsets.all(20.0),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: titleController,
                  decoration: InputDecoration(
                    labelText: 'Title',
                    labelStyle: TextStyle(fontSize: 18),
                    border: OutlineInputBorder(),
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                  ),
                  style: TextStyle(fontSize: 18),
                ),
                SizedBox(height: 20),
                TextField(
                  controller: contentController,
                  decoration: InputDecoration(
                    labelText: 'Content',
                    labelStyle: TextStyle(fontSize: 18),
                    border: OutlineInputBorder(),
                    contentPadding:
                        EdgeInsets.symmetric(vertical: 16, horizontal: 12),
                  ),
                  maxLines: 6,
                  style: TextStyle(fontSize: 18),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              if (titleController.text.isNotEmpty &&
                  contentController.text.isNotEmpty) {
                final response = await _supabase
                    .from('notes')
                    .update({
                      'title': titleController.text,
                      'content': contentController.text,
                    })
                    .eq('id', note['id'])
                    .execute();

                if (response.error == null) {
                  Navigator.pop(context);
                  _fetchNotes();
                } else {
                  print('Error updating note: ${response.error?.message}');
                  ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text('Failed to update note')));
                }
              } else {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content: Text('Title and content cannot be empty')));
              }
            },
            child: Text(
              'Update',
              style: TextStyle(fontSize: 18),
            ),
          ),
        ],
      ),
    );
  }

  // Delete a note
  Future<void> _deleteNote(int id) async {
    final response =
        await _supabase.from('notes').delete().eq('id', id).execute();
    if (response.error == null) {
      _fetchNotes();
    } else {
      print('Error deleting note: ${response.error?.message}');
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Failed to delete note')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Notepad',
          style: TextStyle(
            color: Colors.white,
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.blue,
        elevation: 0,
      ),
      body: _notes.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.note_add,
                    size: 80,
                    color: Colors.blueAccent,
                  ),
                  SizedBox(height: 20),
                  Text(
                    'No notes yet.\nTap the + button to add your first note.',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 18, color: Colors.grey),
                  ),
                ],
              ),
            )
          : ListView.builder(
              itemCount: _notes.length,
              itemBuilder: (context, index) {
                final note = _notes[index];
                return Card(
                  margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                  elevation: 4,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  child: ListTile(
                    contentPadding: EdgeInsets.all(16),
                    title: Text(note['title'],
                        style: TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(note['content']),
                    onTap: () => _updateNote(note),
                    trailing: Row(
                      mainAxisSize:
                          MainAxisSize.min, // Ensures buttons are side by side
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit),
                          onPressed: () => _updateNote(note),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete),
                          onPressed: () => _deleteNote(note['id']),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: Container(
        width: 70,
        height: 70,
        decoration: BoxDecoration(
          color: Colors.blue,
          borderRadius: BorderRadius.circular(35),
        ),
        child: IconButton(
          onPressed: _addNote,
          icon: Icon(
            Icons.add_circle,
            size: 40,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
