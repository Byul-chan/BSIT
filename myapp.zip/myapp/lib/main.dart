import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import 'screens/notes_screen.dart';

void main() async {
  await Supabase.initialize(
    url: 'https://sslaeiqmdfmjramqrgpe.supabase.co',
    anonKey:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InNzbGFlaXFtZGZtanJhbXFyZ3BlIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzQyMDU1NTcsImV4cCI6MjA0OTc4MTU1N30.dr1JxsuTuZcJelNS3WIVMg9oI-S9F7LsahRAyTiYFMM',
  );
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notepad',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: NotepadPage(),
    );
  }
}
