package com.example.simple_notepad

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
